<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('project_investor_interests', function (Blueprint $table): void {
            $table->foreignId('investor_user_id')
                ->nullable()
                ->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('project_investor_interests', function (Blueprint $table): void {
            $table->foreignId('investor_user_id')
                ->nullable(false)
                ->change();
        });
    }
};
