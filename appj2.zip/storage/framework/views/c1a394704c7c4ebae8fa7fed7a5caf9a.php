<?php $__env->startSection('title', 'Inscription envoyée'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .success-container { text-align: center; }
    .success-box { background: #fff; border: 1px solid #dfe3ea; border-radius: 8px; padding: 40px 28px; margin: 0 auto; max-width: 560px; }
    .success-box h1 { margin: 0 0 16px; font-size: clamp(1.7rem, 5vw, 2.3rem); }
    .success-box p { line-height: 1.6; color: #475467; margin: 12px 0; }
    .success-ref { display: inline-block; color: #E8490F; font-weight: 700; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="success-container">
    <div class="success-box">
        <h1>Inscription reçue</h1>
        <p>Merci. Votre demande a bien été envoyée.</p>
        <p>Numéro d'inscription : <span class="success-ref"><?php echo e($registration); ?></span></p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/registration/success.blade.php ENDPATH**/ ?>