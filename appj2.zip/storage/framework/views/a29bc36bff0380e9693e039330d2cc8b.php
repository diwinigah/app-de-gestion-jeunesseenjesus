<?php $__env->startSection('title', 'Projets à financer'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .proj-header { margin-bottom: 24px; }
    .proj-eyebrow { color: #E8490F; font-size: .82rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase; }
    .proj-h1 { margin: 6px 0 10px; font-size: clamp(1.9rem, 5vw, 3rem); }
    .proj-lead { max-width: 680px; color: #5d6678; }
    .proj-empty, .proj-card { background: #fff; border: 1px solid #dfe3ea; border-radius: 8px; }
    .proj-empty { padding: 22px; }
    .proj-grid { display: grid; grid-template-columns: 1fr; gap: 18px; }
    .proj-card { overflow: hidden; box-shadow: 0 1px 3px rgba(15, 23, 42, .08); }
    .proj-card img, .proj-placeholder { width: 100%; height: 210px; object-fit: cover; display: block; }
    .proj-placeholder { display: flex; align-items: center; justify-content: center; background: #d1fae5; color: #064e3b; font-weight: 700; }
    .proj-content { padding: 18px; }
    .proj-summary { color: #5d6678; font-size: .95rem; min-height: 64px; }
    .proj-amounts { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-top: 18px; font-weight: 700; font-size: .92rem; }
    .proj-progress { height: 12px; overflow: hidden; background: #e2e8f0; border-radius: 999px; margin-top: 8px; }
    .proj-progress span { display: block; height: 100%; background: #E8490F; border-radius: 999px; }
    .proj-goal { margin: 8px 0 0; color: #667085; font-size: .82rem; }
    .proj-actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 18px; }
    .proj-btn { display: inline-flex; align-items: center; justify-content: center; min-height: 40px; padding: 0 15px; border-radius: 6px; font-size: .92rem; font-weight: 700; text-decoration: none; cursor: pointer; border: 1px solid transparent; }
    .proj-btn.primary { background: #E8490F; color: #fff; }
    .proj-btn.primary:hover { background: #C73D0A; }
    .proj-btn.secondary { border: 1px solid #E8490F; color: #E8490F; background: #fff; }
    .proj-btn.secondary:hover { background: #fff5f0; }
    .proj-pagination { margin-top: 24px; }
    @media (min-width: 700px) { .proj-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (min-width: 1024px) { .proj-grid { grid-template-columns: repeat(3, 1fr); } }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<header class="proj-header">
    <div class="proj-eyebrow">Projets</div>
    <h1 class="proj-h1">Projets à financer</h1>
    <p class="proj-lead">Découvrez les projets publiés et accompagnez ceux qui construisent l'avenir de Jeunesse en Jésus.</p>
</header>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($projects->isEmpty()): ?>
    <section class="proj-empty">
        <h2>Aucun projet publié</h2>
        <p>Les projets à financer seront affichés ici dès leur publication.</p>
    </section>
<?php else: ?>
    <section class="proj-grid">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $progress = $projectService->getProgressPercentage($project);
            ?>

            <article class="proj-card animate-left">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->featured_image_path): ?>
                    <img src="<?php echo e(asset('storage/' . $project->featured_image_path)); ?>" alt="<?php echo e($project->title); ?>">
                <?php else: ?>
                    <div class="proj-placeholder">Projet</div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="proj-content">
                    <h2><?php echo e($project->title); ?></h2>
                    <p class="proj-summary"><?php echo e($project->summary); ?></p>

                    <div class="proj-amounts">
                        <span><?php echo e(number_format((float) $project->funded_amount, 0, ',', ' ')); ?> XOF</span>
                        <span><?php echo e(number_format($progress, 2, ',', ' ')); ?> %</span>
                    </div>
                    <div class="proj-progress" aria-label="Progression du financement">
                        <span style="width: <?php echo e($progress); ?>%"></span>
                    </div>
                    <p class="proj-goal">Collecté : <?php echo e(number_format($project->funded_amount, 0, ',', ' ')); ?> XOF | Objectif : <?php echo e(number_format($project->funding_goal, 0, ',', ' ')); ?> XOF</p>

                    <div class="proj-actions">
                        <a class="proj-btn primary" href="<?php echo e(route('projects.show', ['project' => $project->slug])); ?>">Voir</a>
                        <a class="proj-btn secondary" href="<?php echo e(route('projects.invest.form', ['project' => $project->slug])); ?>">Investir</a>
                    </div>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </section>

    <div class="proj-pagination">
        <?php echo e($projects->links()); ?>

    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/projects/index.blade.php ENDPATH**/ ?>