

<style>
/* ═══════════════════════════════════
   ANIMATIONS GLOBALES
═══════════════════════════════════ */

/* Fade-in de base */
.anim-fade {
    opacity: 0;
    transform: translateY(28px);
    transition: opacity 0.6s ease, transform 0.6s ease;
}
.anim-fade.is-visible {
    opacity: 1;
    transform: translateY(0);
}

/* Fade depuis la gauche */
.anim-left {
    opacity: 0;
    transform: translateX(-30px);
    transition: opacity 0.6s ease, transform 0.6s ease;
}
.anim-left.is-visible {
    opacity: 1;
    transform: translateX(0);
}

/* Fade depuis la droite */
.anim-right {
    opacity: 0;
    transform: translateX(30px);
    transition: opacity 0.6s ease, transform 0.6s ease;
}
.anim-right.is-visible {
    opacity: 1;
    transform: translateX(0);
}

/* Zoom in */
.anim-zoom {
    opacity: 0;
    transform: scale(0.92);
    transition: opacity 0.5s ease, transform 0.5s ease;
}
.anim-zoom.is-visible {
    opacity: 1;
    transform: scale(1);
}

/* Délais échelonnés pour les grilles */
.anim-delay-1 { transition-delay: 0.1s; }
.anim-delay-2 { transition-delay: 0.2s; }
.anim-delay-3 { transition-delay: 0.3s; }
.anim-delay-4 { transition-delay: 0.4s; }
.anim-delay-5 { transition-delay: 0.5s; }
.anim-delay-6 { transition-delay: 0.6s; }

/* Barre de progression animée */
.sp-progress-fill,
.progress-bar-fill {
    width: 0% !important;
    transition: width 1.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
}
.sp-progress-fill.anim-bar-done,
.progress-bar-fill.anim-bar-done {
    width: var(--target-width) !important;
}

/* Compteur animé */
.anim-counter {
    display: inline-block;
    font-variant-numeric: tabular-nums;
}

/* Hover cards global */
.anim-card-hover {
    transition: transform 0.22s ease, box-shadow 0.22s ease;
}
.anim-card-hover:hover {
    transform: translateY(-4px);
    box-shadow: 0 12px 32px rgba(61,43,31,0.12);
}

/* Pulse sur les boutons CTA */
@keyframes pulse-cta {
    0%, 100% { box-shadow: 0 4px 16px rgba(232,73,15,0.3); }
    50% { box-shadow: 0 4px 28px rgba(232,73,15,0.55); }
}
.anim-pulse {
    animation: pulse-cta 2.5s ease-in-out infinite;
}

/* Réduire animations si préférence système */
@media (prefers-reduced-motion: reduce) {
    .anim-fade, .anim-left, .anim-right, .anim-zoom {
        opacity: 1 !important;
        transform: none !important;
        transition: none !important;
    }
    .anim-pulse { animation: none !important; }
}
</style>

<script>
(function () {
    'use strict';

    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
    }

    /* ═══════════════════════════════
       1. FADE-IN AU SCROLL
    ═══════════════════════════════ */
    function initScrollAnimations() {
        const targets = document.querySelectorAll(
            '.anim-fade, .anim-left, .anim-right, .anim-zoom'
        );
        if (!targets.length) return;

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        targets.forEach(function (el) { observer.observe(el); });
    }

    /* ═══════════════════════════════
       2. BARRES DE PROGRESSION
    ═══════════════════════════════ */
    function initProgressBars() {
        const bars = document.querySelectorAll(
            '.sp-progress-fill, .progress-bar-fill, [data-progress]'
        );
        if (!bars.length) return;

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    const el = entry.target;
                    const inlineWidth = el.style.width || el.getAttribute('style') || '';
                    const styleMatch = (inlineWidth || '').match(/width\s*:\s*([0-9\.]+%)/i);
                    const target = el.dataset.progress
                        || (styleMatch ? styleMatch[1] : el.getAttribute('data-target') || '0%');

                    el.style.setProperty('--target-width', target);
                    // reset to 0 then animate
                    el.style.width = '0%';
                    requestAnimationFrame(function () {
                        setTimeout(function () {
                            el.classList.add('anim-bar-done');
                        }, 100);
                    });
                    observer.unobserve(el);
                }
            });
        }, { threshold: 0.3 });

        bars.forEach(function (bar) { observer.observe(bar); });
    }

    /* ═══════════════════════════════
       3. COMPTEURS ANIMÉS
    ═══════════════════════════════ */
    function animateCounter(el) {
        const raw = el.dataset.target || el.textContent || '';
        const target = parseInt(String(raw).replace(/[^0-9\-]/g, ''), 10);
        if (isNaN(target)) return;
        const duration = parseInt(el.dataset.duration || 1800, 10);
        const start = performance.now();
        const separator = el.dataset.separator || ' ';

        function formatNumber(n) {
            return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, separator);
        }

        function step(now) {
            const elapsed = now - start;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = formatNumber(eased * target);
            if (progress < 1) {
                requestAnimationFrame(step);
            } else {
                el.textContent = formatNumber(target);
            }
        }

        requestAnimationFrame(step);
    }

    function initCounters() {
        const counters = document.querySelectorAll('.anim-counter, [data-counter]');
        if (!counters.length) return;

        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });

        counters.forEach(function (c) { observer.observe(c); });
    }

    /* ═══════════════════════════════
       4. INITIALISATION
    ═══════════════════════════════ */
    function initAnimations() {
        try {
            initScrollAnimations();
            initProgressBars();
            initCounters();
        } catch (e) {
            // fail silently
            console.error('Init animations error', e);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initAnimations);
    } else {
        initAnimations();
    }
})();
</script>
<?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/partials/animations.blade.php ENDPATH**/ ?>