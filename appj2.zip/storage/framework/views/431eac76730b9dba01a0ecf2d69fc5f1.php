<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Nathan\Desktop\appj2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>