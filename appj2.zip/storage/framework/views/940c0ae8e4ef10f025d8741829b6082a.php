

<?php $__env->startSection('title', 'Sponsoring ' . ($edition?->name ?? 'Camp')); ?>

<?php $__env->startPush('styles'); ?>

<style>
/* ═══════════════════════════════════
   BASE
═══════════════════════════════════ */
*, *::before, *::after { box-sizing: border-box; }

.sp-page {
    max-width: 960px;
    margin: 0 auto;
    padding: 0 1rem 4rem;
    overflow-x: hidden;
}

.sp-section {
    margin-bottom: 2.5rem;
    width: 100%;
}

.sp-section-title {
    font-size: 1.05rem;
    font-weight: 800;
    color: #3D2B1F;
    margin-bottom: 1.25rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding-bottom: 0.6rem;
    border-bottom: 2px solid #f0e8e4;
}

.sp-section-title .sp-icon svg { width: 20px; height: 20px; color: #E8490F; }

/* ═══════════════════════════════════
   HERO
═══════════════════════════════════ */
.sp-hero {
    position: relative;
    border-radius: 16px;
    overflow: hidden;
    margin-bottom: 2rem;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
}
.sp-hero img {
    width: 100%;
    max-height: 260px;
    object-fit: cover;
    display: block;
    filter: brightness(0.65);
}
.sp-hero-overlay {
    position: absolute;
    inset: 0;
    background: linear-gradient(to bottom, rgba(61,43,31,0.2), rgba(61,43,31,0.82));
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 1.5rem 1rem;
    text-align: center;
}
.sp-hero-tag {
    background: #E8490F;
    color: #fff;
    padding: 0.25rem 1rem;
    border-radius: 30px;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    margin-bottom: 0.75rem;
}
.sp-hero-title {
    font-size: 1.8rem;
    font-weight: 900;
    color: #fff;
    margin: 0 0 0.4rem;
    text-shadow: 0 2px 8px rgba(0,0,0,0.4);
    word-break: break-word;
}
.sp-hero-theme {
    font-size: 1rem;
    color: #f9c97c;
    font-style: italic;
    font-weight: 600;
    margin: 0.2rem 0;
}
.sp-hero-verse {
    font-size: 0.85rem;
    color: rgba(255,255,255,0.85);
    margin: 0.4rem 0;
}
.sp-hero-dates {
    font-size: 0.88rem;
    color: #fff;
    margin-top: 0.6rem;
    background: rgba(255,255,255,0.15);
    padding: 0.35rem 0.9rem;
    border-radius: 20px;
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    backdrop-filter: blur(4px);
}
.sp-hero-dates .sp-icon svg {
    width: 16px !important;
    height: 16px !important;
    color: #fff;
    flex-shrink: 0;
}
.sp-hero-no-img {
    background: linear-gradient(135deg, #3D2B1F 0%, #6b3a25 100%);
    padding: 2.5rem 1.5rem;
    text-align: center;
    border-radius: 16px;
    margin-bottom: 2rem;
}

/* ═══════════════════════════════════
   INTRO
═══════════════════════════════════ */
.sp-intro {
    font-size: 0.95rem;
    line-height: 1.85;
    color: #444;
    background: #fdf6f3;
    border-left: 4px solid #E8490F;
    padding: 1.25rem 1.25rem;
    border-radius: 0 12px 12px 0;
    word-break: break-word;
}

.sp-salutation {
    font-size: 1rem;
    font-weight: 700;
    color: #3D2B1F;
    margin-bottom: 0.6rem;
}

/* ═══════════════════════════════════
   PROGRESSION
═══════════════════════════════════ */
.sp-progress-grid {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}
.sp-progress-card {
    background: #fff;
    border: 1px solid #f0e8e4;
    border-radius: 14px;
    padding: 1.25rem;
    width: 100%;
}
.sp-progress-top {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
    margin-bottom: 0.75rem;
}
.sp-progress-label { font-size: 0.85rem; color: #666; font-weight: 600; }
.sp-progress-value { font-size: 0.9rem; font-weight: 800; color: #3D2B1F; }
.sp-progress-track {
    background: #f0e8e4;
    border-radius: 99px;
    height: 12px;
    overflow: hidden;
    width: 100%;
}
.sp-progress-fill {
    background: linear-gradient(90deg, #E8490F, #ff6b35);
    height: 100%;
    border-radius: 99px;
    transition: width 1s ease;
}
.sp-progress-fill-green { background: linear-gradient(90deg, #16a34a, #22c55e); }
.sp-progress-pct {
    font-size: 0.8rem;
    color: #E8490F;
    font-weight: 700;
    text-align: right;
    margin-top: 0.35rem;
    display: block;
}

/* ═══════════════════════════════════
   BOURSES DUO
═══════════════════════════════════ */
.sp-bourse-duo {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}
.sp-bourse-card {
    background: #fff;
    border: 2px solid #f0e8e4;
    border-radius: 14px;
    padding: 1.5rem 1rem;
    text-align: center;
    transition: transform 0.2s, box-shadow 0.2s;
    min-width: 0; /* empêche débordement */
}
.sp-bourse-featured { border-color: #E8490F; background: linear-gradient(135deg, #fff8f6, #fff); }
.sp-bourse-libre { border-color: #f9c97c; background: linear-gradient(135deg, #fffdf5, #fff); }
.sp-bourse-icon { font-size: 1.8rem; margin-bottom: 0.5rem; }
.sp-bourse-icon .sp-icon svg { width: 32px; height: 32px; color: #E8490F; }
.sp-bourse-libre .sp-bourse-icon .sp-icon svg { color: #d4a017; }
.sp-bourse-card h4 { font-size: 0.9rem; font-weight: 800; color: #3D2B1F; margin-bottom: 0.35rem; }
.sp-bourse-card p { font-size: 0.75rem; color: #888; margin-bottom: 0.5rem; line-height: 1.4; }
.sp-bourse-amount { font-size: 1.2rem; font-weight: 900; color: #E8490F; white-space: nowrap; }
.sp-bourse-amount small { font-size: 0.68rem; font-weight: 600; color: #aaa; display: block; margin-top: 0.2rem; }
.sp-bourse-libre-amount { color: #d4a017 !important; }

/* ═══════════════════════════════════
   CATÉGORIES
═══════════════════════════════════ */
.sp-categorie-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0.75rem;
}
.sp-categorie-card {
    background: #fff;
    border: 1px solid #f0e8e4;
    border-radius: 14px;
    padding: 1rem 0.5rem;
    text-align: center;
    min-width: 0;
}
.sp-categorie-card h4 { font-size: 0.82rem; font-weight: 0.82rem; color: #3D2B1F; margin: 0.4rem 0 0.35rem; }
.sp-categorie-card .sp-bourse-amount { font-size: 0.95rem; white-space: nowrap; }

/* ═══════════════════════════════════
   RÉPARTITION
═══════════════════════════════════ */
.sp-repartition {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}
.sp-rep-card {
    background: #fff;
    border: 1px solid #f0e8e4;
    border-radius: 14px;
    padding: 1.25rem;
    min-width: 0;
}
.sp-rep-card h4 { font-size: 0.85rem; font-weight: 700; color: #3D2B1F; margin-bottom: 0.75rem; }
.sp-rep-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.45rem 0;
    border-bottom: 1px solid #f9f3f0;
    font-size: 0.85rem;
    gap: 0.5rem;
}
.sp-rep-row:last-child { border-bottom: none; }
.sp-rep-row span { color: #555; }
.sp-rep-row strong { color: #3D2B1F; font-weight: 700; white-space: nowrap; }
.sp-rep-total {
    background: #fdf6f3;
    border-radius: 8px;
    padding: 0.5rem 0.75rem;
    margin-top: 0.5rem;
    display: flex;
    justify-content: space-between;
    font-weight: 800;
    color: #E8490F;
    font-size: 0.9rem;
}

/* ═══════════════════════════════════
   BUDGET TABLE
═══════════════════════════════════ */
.sp-budget-wrapper {
    width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    border-radius: 12px;
}
.sp-budget-table {
    width: 100%;
    min-width: 500px; /* scroll horizontal sur mobile si nécessaire */
    border-collapse: collapse;
    background: #fff;
    font-size: 0.85rem;
}
.sp-budget-table thead tr { background: #3D2B1F; color: #fff; }
.sp-budget-table th {
    padding: 0.7rem 0.75rem;
    text-align: left;
    font-weight: 700;
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    white-space: nowrap;
}
.sp-budget-table td {
    padding: 0.6rem 0.75rem;
    border-bottom: 1px solid #f0e8e4;
    color: #444;
    vertical-align: middle;
}
.sp-budget-table tbody tr:hover { background: #fdf6f3; }
.sp-budget-table tbody tr:last-child td { border-bottom: none; }
.sp-budget-total-row td {
    background: #fdf6f3;
    font-weight: 800;
    color: #3D2B1F;
    border-top: 2px solid #E8490F;
}
.sp-budget-amount {
    text-align: right;
    font-weight: 600;
    color: #3D2B1F;
    white-space: nowrap;
}
.sp-budget-total-amount { color: #E8490F; font-size: 0.95rem; }

/* ═══════════════════════════════════
   NATURE
═══════════════════════════════════ */
.sp-nature-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 0.75rem;
}
.sp-nature-card {
    display: flex;
    align-items: flex-start;
    gap: 0.75rem;
    background: #fdf6f3;
    border-radius: 12px;
    padding: 0.9rem 1rem;
    border: 1px solid #f0e8e4;
    min-width: 0;
}
.sp-nature-num {
    background: #E8490F;
    color: #fff;
    border-radius: 50%;
    min-width: 26px;
    height: 26px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    font-weight: 800;
    flex-shrink: 0;
}
.sp-nature-card p {
    font-size: 0.85rem;
    color: #444;
    margin: 0;
    line-height: 1.5;
    word-break: break-word;
    min-width: 0;
}

/* ═══════════════════════════════════
   PAIEMENT
═══════════════════════════════════ */
.sp-payment-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}
.sp-payment-card {
    background: #fff;
    border: 1px solid #f0e8e4;
    border-radius: 14px;
    padding: 1.25rem 0.75rem;
    text-align: center;
    min-width: 0;
    word-break: break-word;
}
.sp-payment-icon .sp-icon svg { width: 36px; height: 36px; color: #3D2B1F; }
.sp-payment-card h4 { font-weight: 800; color: #3D2B1F; margin-bottom: 0.4rem; font-size: 0.88rem; }
.sp-payment-card p { font-size: 0.8rem; color: #555; margin: 0.2rem 0; line-height: 1.5; word-break: break-all; }
.sp-payment-btn {
    display: inline-block;
    margin-top: 0.6rem;
    background: #E8490F;
    color: #fff;
    padding: 0.45rem 1rem;
    border-radius: 25px;
    font-size: 0.8rem;
    font-weight: 700;
    text-decoration: none;
    transition: background 0.2s;
    white-space: nowrap;
}
.sp-payment-btn:hover { background: #c73d0d; color: #fff; }

/* ═══════════════════════════════════
   CONTACT
═══════════════════════════════════ */
.sp-contact {
    background: linear-gradient(135deg, #3D2B1F, #6b3a25);
    border-radius: 16px;
    padding: 2rem 1.25rem;
    text-align: center;
    color: #fff;
}
.sp-contact h3 { color: #fff; font-size: 1.1rem; font-weight: 800; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }
.sp-contact h3 .sp-icon svg { width: 20px; height: 20px; color: #fff; }
.sp-contact-items { display: flex; flex-wrap: wrap; justify-content: center; gap: 1.25rem; }
.sp-contact-item { display: flex; align-items: center; gap: 0.5rem; font-size: 0.9rem; font-weight: 600; color: #fff; word-break: break-word; }
.sp-contact-item .sp-icon svg { width: 18px; height: 18px; color: #fff; }

/* ═══════════════════════════════════
   CLOSED
═══════════════════════════════════ */
.sp-closed { text-align: center; padding: 4rem 1rem; }
.sp-closed-icon .sp-icon svg { width: 56px; height: 56px; color: #E8490F; margin-bottom: 1rem; }
.sp-closed h1 { color: #3D2B1F; font-size: 1.4rem; margin-bottom: 0.75rem; }
.sp-closed p { color: #888; }

/* ═══════════════════════════════════
   RESPONSIVE TABLETTE
═══════════════════════════════════ */
@media (max-width: 768px) {
    .sp-hero-title { font-size: 1.4rem; }
    .sp-repartition { grid-template-columns: 1fr; }
    .sp-categorie-grid { grid-template-columns: repeat(2, 1fr); }
    .sp-nature-grid { grid-template-columns: 1fr; }
    .sp-payment-grid { grid-template-columns: repeat(2, 1fr); }
}

/* ═══════════════════════════════════
   RESPONSIVE MOBILE
═══════════════════════════════════ */
@media (max-width: 480px) {
    .sp-page { padding: 0 0.75rem 3rem; }
    .sp-hero-title { font-size: 1.2rem; }
    .sp-hero-theme { font-size: 0.88rem; }
    .sp-hero-dates {
        font-size: 0.78rem;
        padding: 0.3rem 0.75rem;
        white-space: normal;
        text-align: center;
        display: inline-flex;
        flex-wrap: wrap;
        justify-content: center;
    }
    .sp-hero-dates .sp-icon svg {
        width: 14px !important;
        height: 14px !important;
    }
    .sp-bourse-duo { grid-template-columns: 1fr; }
    .sp-bourse-card { padding: 1.25rem 1rem; }
    .sp-categorie-grid { grid-template-columns: repeat(2, 1fr); }
    .sp-payment-grid { grid-template-columns: 1fr; }
    .sp-nature-grid { grid-template-columns: 1fr; }
    .sp-contact { padding: 1.5rem 1rem; border-radius: 12px; }
    .sp-contact-items { flex-direction: column; gap: 0.75rem; }
    .sp-section-title { font-size: 0.95rem; }
    .sp-budget-table { font-size: 0.78rem; min-width: 400px; }
    .sp-budget-table th, .sp-budget-table td { padding: 0.5rem 0.5rem; }
    .sp-repartition { grid-template-columns: 1fr; }
    .sp-progress-value { font-size: 0.82rem; }
}

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$edition): ?>
    <div class="sp-closed">
        <div class="sp-closed-icon"><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a7 7 0 00-7 7v1a2 2 0 01-2 2v1a2 2 0 002 2 7 7 0 007 7 7 7 0 007-7 7 7 0 00-7-7z"/></svg>
        </span></div>
        <h1>Page de sponsoring</h1>
        <p>Aucune campagne de sponsoring active pour le moment. Revenez bientôt !</p>
    </div>

<?php else: ?>

<div class="sp-page">

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->cover_image_path): ?>
    <div class="sp-hero">
        <div class="sp-hero-img">
            <img src="<?php echo e(Storage::url($edition->cover_image_path)); ?>" alt="<?php echo e($edition->name); ?>">
        </div>
        <div class="sp-hero-overlay">
            <div class="sp-hero-tag">Sponsoring</div>
            <h2 class="sp-hero-title"><?php echo e($edition->name); ?></h2>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_theme): ?>
                <div class="sp-hero-theme">« <?php echo e($edition->sponsoring_theme); ?> »</div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_verse): ?>
                <div class="sp-hero-verse"><?php echo e($edition->sponsoring_verse); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->camp_start_date && $edition->camp_end_date): ?>
                <div class="sp-hero-dates"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                </span> <?php echo e(\Carbon\Carbon::parse($edition->camp_start_date)->translatedFormat('d F')); ?>

                —
                <?php echo e(\Carbon\Carbon::parse($edition->camp_end_date)->translatedFormat('d F Y')); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php else: ?>
    <div class="sp-hero-no-img">
        <div class="sp-hero-tag">Sponsoring</div>
        <h2 class="sp-hero-title"><?php echo e($edition->name); ?></h2>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_theme): ?>
            <div class="sp-hero-theme">« <?php echo e($edition->sponsoring_theme); ?> »</div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_salutation): ?>
    <div class="sp-section"><div class="sp-salutation"><?php echo e(e($edition->sponsoring_salutation)); ?></div></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_intro): ?>
    <div class="sp-section sp-intro"><?php echo nl2br(html_entity_decode(e($edition->sponsoring_intro))); ?></div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <div class="sp-section sp-progress-grid">
        <div class="sp-progress-card">
            <div class="sp-progress-top">
                <div class="sp-progress-label">Budget collecté</div>
                <div class="sp-progress-value"><?php echo e(number_format($edition->budget_collected ?? 0, 0, ',', ' ')); ?> / <?php echo e(number_format($edition->budget_total ?? 0, 0, ',', ' ')); ?> FCFA</div>
            </div>
            <?php $budgetPct = ($edition->budget_total ?? 0) > 0 ? min(100, round((($edition->budget_collected ?? 0) / $edition->budget_total) * 100)) : 0; ?>
            <div class="sp-progress-track"><div class="sp-progress-fill" style="width: <?php echo e($budgetPct); ?>%;"></div></div>
            <span class="sp-progress-pct"><?php echo e($budgetPct); ?>% atteint</span>
    </div>

    

    
    <div class="sp-section">
        <div class="sp-section-title"><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 14l9-5-9-5-9 5 9 5z"/></svg>
        </span> Types de bourses</div>

        <div class="sp-bourse-duo">
            <div class="sp-bourse-card sp-bourse-featured">
                <div class="sp-bourse-icon"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.95a1 1 0 00.95.69h4.153c.969 0 1.371 1.24.588 1.81l-3.36 2.44a1 1 0 00-.364 1.118l1.287 3.95c.3.921-.755 1.688-1.538 1.118l-3.36-2.44a1 1 0 00-1.176 0l-3.36 2.44c-.783.57-1.838-.197-1.538-1.118l1.287-3.95a1 1 0 00-.364-1.118L2.07 9.377c-.783-.57-.38-1.81.588-1.81h4.153a1 1 0 00.95-.69l1.286-3.95z"/></svg>
                </span></div>
                <h4><?php echo e($edition->bourse_pleine_label); ?></h4>
                <p><?php echo e($edition->bourse_pleine_desc); ?></p>
                <div class="sp-bourse-amount"><?php echo e(number_format($edition->bourse_pleine_amount ?? 0, 0, ',', ' ')); ?> FCFA <small>par campeur</small></div>
            </div>

            <div class="sp-bourse-card sp-bourse-libre">
                <div class="sp-bourse-icon"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 21s-8-4.35-8-10a5 5 0 0110 0 5 5 0 0110 0c0 5.65-8 10-8 10z"/></svg>
                </span></div>
                <h4><?php echo e($edition->bourse_partielle_label); ?></h4>
                <p><?php echo e($edition->bourse_partielle_desc); ?></p>
                <div class="sp-bourse-amount sp-bourse-libre-amount">Libre</div>
            </div>
        </div>
    </div>

    
    <div class="sp-section">
        <div class="sp-section-title"><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 14l9-5-9-5-9 5 9 5z"/></svg>
        </span> Frais de participation par catégorie</div>

        <div class="sp-categorie-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->bourse_adulte_amount > 0): ?>
                <div class="sp-categorie-card">
                    <h4><?php echo e($edition->categorie_adulte_label); ?></h4>
                    <div class="sp-bourse-amount"><?php echo e(number_format($edition->bourse_adulte_amount, 0, ',', ' ')); ?> FCFA</div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->bourse_etudiant_amount > 0): ?>
                <div class="sp-categorie-card">
                    <h4><?php echo e($edition->categorie_etudiant_label); ?></h4>
                    <div class="sp-bourse-amount"><?php echo e(number_format($edition->bourse_etudiant_amount, 0, ',', ' ')); ?> FCFA</div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->bourse_lycee_amount > 0): ?>
                <div class="sp-categorie-card">
                    <h4><?php echo e($edition->categorie_lycee_label); ?></h4>
                    <div class="sp-bourse-amount"><?php echo e(number_format($edition->bourse_lycee_amount, 0, ',', ' ')); ?> FCFA</div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->bourse_enfant_amount > 0): ?>
                <div class="sp-categorie-card">
                    <h4><?php echo e($edition->categorie_enfant_label); ?></h4>
                    <div class="sp-bourse-amount"><?php echo e(number_format($edition->bourse_enfant_amount, 0, ',', ' ')); ?> FCFA</div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <?php
        $totalParticipants = (int)($edition->participants_adultes ?? 0)
                           + (int)($edition->participants_etudiants ?? 0)
                           + (int)($edition->participants_lycee ?? 0)
                           + (int)($edition->participants_enfants ?? 0);
    ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($totalParticipants > 0 || !empty($edition->participants_geo)): ?>
    <div class="sp-section">
        <div class="sp-section-title"><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7l9-4 9 4"/><path d="M21 7v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7"/></svg>
        </span> Pévision des participants</div>

        <div class="sp-repartition">
            <div class="sp-rep-card">
                <h4>Par catégorie</h4>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((int)($edition->participants_adultes ?? 0) > 0): ?>
                    <div class="sp-rep-row"><span><?php echo e($edition->categorie_adulte_label ?? 'Adultes'); ?></span><strong><?php echo e(number_format($edition->participants_adultes, 0, ',', ' ')); ?></strong></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((int)($edition->participants_etudiants ?? 0) > 0): ?>
                    <div class="sp-rep-row"><span><?php echo e($edition->categorie_etudiant_label ?? 'Étudiants'); ?></span><strong><?php echo e(number_format($edition->participants_etudiants, 0, ',', ' ')); ?></strong></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((int)($edition->participants_lycee ?? 0) > 0): ?>
                    <div class="sp-rep-row"><span><?php echo e($edition->categorie_lycee_label ?? 'Lycée'); ?></span><strong><?php echo e(number_format($edition->participants_lycee, 0, ',', ' ')); ?></strong></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((int)($edition->participants_enfants ?? 0) > 0): ?>
                    <div class="sp-rep-row"><span><?php echo e($edition->categorie_enfant_label ?? 'Enfants'); ?></span><strong><?php echo e(number_format($edition->participants_enfants, 0, ',', ' ')); ?></strong></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="sp-rep-total"><span>Total</span><strong><?php echo e(number_format($totalParticipants, 0, ',', ' ')); ?></strong></div>
            </div>

            <div class="sp-rep-card">
                <h4>Par localisation</h4>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($edition->participants_geo) && is_array($edition->participants_geo)): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $edition->participants_geo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sp-rep-row"><span><?php echo e($item['ville'] ?? ($item->ville ?? '—')); ?></span><strong><?php echo e($item['nombre'] ?? ($item->nombre ?? '—')); ?></strong></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php else: ?>
                    <p>Aucune prévision de participant par localisation renseignée.</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->budget_expenses && count($edition->budget_expenses) > 0): ?>
    <?php
        $totalDepenses = collect($edition->budget_expenses)
            ->sum(fn($e) => ($e['prix_unitaire'] ?? 0) * ($e['quantite'] ?? 1));
    ?>

        <div class="sp-budget-wrapper">
        <table class="sp-budget-table">
            <thead>
                <tr>
                    <th>Prix unitaire</th>
                    <th>Qté</th>
                    <th class="sp-budget-amount">Montant (FCFA)</th>
                </tr>
            </thead>
            <tbody>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $edition->budget_expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $montant = ($expense['prix_unitaire'] ?? 0) * ($expense['quantite'] ?? 1); ?>
                <tr>
                    <td><?php echo e($expense['designation'] ?? '—'); ?></td>
                    <td><?php echo e(number_format($expense['prix_unitaire'] ?? 0, 0, ',', ' ')); ?></td>
                    <td><?php echo e($expense['quantite'] ?? 1); ?></td>
                    <td class="sp-budget-amount"><?php echo e(number_format($montant, 0, ',', ' ')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <tr class="sp-budget-total-row">
                    <td colspan="3">TOTAL</td>
                    <td class="sp-budget-total-amount"><?php echo e(number_format($totalDepenses, 0, ',', ' ')); ?></td>
                </tr>
            </tbody>
        </table>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->nature_contributions && count($edition->nature_contributions) > 0): ?>
        <div class="sp-section">
        <div class="sp-section-title"><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7l9-4 9 4"/><path d="M21 7v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7"/></svg>
        </span> Apports en nature</div>
        <div class="sp-nature-grid">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $edition->nature_contributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="sp-nature-card">
                            <div class="sp-nature-num"><span class="sp-icon"> 
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 4v16"/><path d="M6 8v8"/><path d="M18 8v8"/></svg>
                            </span><?php echo e($index + 1); ?></div>
                            <p><?php echo is_array($item) && isset($item['designation']) ? html_entity_decode(e($item['designation'])) : html_entity_decode(e($item)); ?></p>
                        </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_flooz || $edition->payment_mixx || $edition->payment_account_name || $edition->payment_paypal): ?>
        <div class="sp-section">
        <div class="sp-section-title"><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>
        </span> Comment contribuer ?</div>
        <div class="sp-payment-grid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_flooz): ?>
            <div class="sp-payment-card">
                <div class="sp-payment-icon"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 16V8a2 2 0 00-2-2h-3l-2-3H10L8 6H5a2 2 0 00-2 2v8a2 2 0 002 2h14a2 2 0 002-2z"/></svg>
                </span></div>
                <h4>Flooz</h4>
                <p><?php echo e(e($edition->payment_flooz)); ?></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_mixx): ?>
            <div class="sp-payment-card">
                <div class="sp-payment-icon"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 16V8a2 2 0 00-2-2h-3l-2-3H10L8 6H5a2 2 0 00-2 2v8a2 2 0 002 2h14a2 2 0 002-2z"/></svg>
                </span></div>
                <h4>Mixx by YAS</h4>
                <p><?php echo e(e($edition->payment_mixx)); ?></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_account_name || $edition->payment_account_number): ?>
            <div class="sp-payment-card">
                <div class="sp-payment-icon"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 21h18"/><path d="M4 10h16v11H4z"/><path d="M12 4l8 6H4l8-6z"/></svg>
                </span></div>
                <h4>Virement bancaire</h4>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_account_name): ?>
                    <p><strong>Compte :</strong> <?php echo e(e($edition->payment_account_name)); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_account_number): ?>
                    <p><strong>N° :</strong> <?php echo e(e($edition->payment_account_number)); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_iban): ?>
                    <p><strong>IBAN :</strong> <?php echo e(e($edition->payment_iban)); ?></p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->payment_paypal): ?>
            <div class="sp-payment-card">
                <div class="sp-payment-icon"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7h18v10a2 2 0 01-2 2H5a2 2 0 01-2-2V7z"/><path d="M16 3l-1 4"/><path d="M8 3l1 4"/></svg>
                </span></div>
                <h4>PayPal</h4>
                <p><a class="sp-payment-btn" href="<?php echo e(e($edition->payment_paypal)); ?>" target="_blank" rel="noopener">Contribuer via PayPal →</a></p>
            </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_contact_phone || $edition->sponsoring_contact_email): ?>
    <div class="sp-section sp-contact">
        <h3><span class="sp-icon"> 
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92V21a2 2 0 01-2 2 19 19 0 01-8.63-2.56A19 19 0 013.3 8.63 19 19 0 016.58 3 2 2 0 018.6 1h3.09a2 2 0 012 1.72c.12.86.54 2.24.9 3.3a2 2 0 01-.45 2.11L12.7 10.7"/></svg>
        </span> Nous contacter</h3>
        <div class="sp-contact-items">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_contact_phone): ?>
                <div class="sp-contact-item"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92V21a2 2 0 01-2 2 19 19 0 01-8.63-2.56A19 19 0 013.3 8.63 19 19 0 016.58 3 2 2 0 018.6 1h3.09a2 2 0 012 1.72c.12.86.54 2.24.9 3.3a2 2 0 01-.45 2.11L12.7 10.7"/></svg>
                </span> <?php echo e(e($edition->sponsoring_contact_phone)); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($edition->sponsoring_contact_email): ?>
                <div class="sp-contact-item"><span class="sp-icon"> 
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 8l9 6 9-6"/><path d="M21 8v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8"/></svg>
                </span> <a href="mailto:<?php echo e(e($edition->sponsoring_contact_email)); ?>"><?php echo e(e($edition->sponsoring_contact_email)); ?></a></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

</div>

<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/sponsoring/index.blade.php ENDPATH**/ ?>