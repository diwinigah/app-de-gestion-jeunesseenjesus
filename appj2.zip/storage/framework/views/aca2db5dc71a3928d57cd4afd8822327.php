<?php
    $brandName = filament()->getBrandName();
    $brandLogo = filament()->getBrandLogo();
    $darkModeBrandLogo = filament()->getDarkModeBrandLogo();
    $logo = filled($darkModeBrandLogo) && request()->cookie('theme') === 'dark'
        ? $darkModeBrandLogo
        : $brandLogo;
?>

<div <?php echo e($attributes->class(['jj-filament-brand'])); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($logo)): ?>
        <img
            alt="<?php echo e(__('filament-panels::layout.logo.alt', ['name' => $brandName])); ?>"
            class="jj-filament-brand__logo"
            src="<?php echo e($logo); ?>"
        />
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <span class="jj-filament-brand__name">
        <?php echo e($brandName); ?>

    </span>
</div>
<?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/vendor/filament-panels/components/logo.blade.php ENDPATH**/ ?>