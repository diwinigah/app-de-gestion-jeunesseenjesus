

<?php $__env->startSection('title', 'Se connecter - Investisseur'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .inv-login-container { width: min(100%, 500px); margin: 40px auto; }
    .inv-login-box { background: #fff; border: 1px solid #dfe3ea; border-radius: 8px; padding: 24px; }
    .inv-login-h1 { margin: 0 0 24px; font-size: 1.8rem; color: #333; }
    .inv-login-group { margin-bottom: 16px; }
    .inv-login-label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 0.9rem; color: #333; }
    .inv-login-input { width: 100%; padding: 10px; border: 1px solid #dfe3ea; border-radius: 4px; font-size: 0.95rem; font-family: Arial, sans-serif; color: #333; }
    .inv-login-input:focus { outline: none; border-color: #E8490F; box-shadow: 0 0 0 3px rgba(232, 73, 15, 0.1); }
    .inv-login-error { color: #dc2626; font-size: 0.85rem; margin-top: 4px; }
    .inv-login-group.error .inv-login-input { border-color: #dc2626; }
    .inv-login-btn { display: inline-flex; width: 100%; align-items: center; justify-content: center; min-height: 44px; background: #E8490F; color: #fff; border: none; border-radius: 6px; font-size: 0.95rem; font-weight: 700; cursor: pointer; margin-top: 12px; }
    .inv-login-btn:hover { background: #C73D0A; }
    .inv-login-links { text-align: center; margin-top: 16px; }
    .inv-login-links div { margin-bottom: 8px; }
    .inv-login-links a { color: #E8490F; text-decoration: none; font-weight: 600; }
    .inv-login-links a:hover { text-decoration: underline; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="inv-login-container">
    <div class="inv-login-box">
        <h1 class="inv-login-h1">Se connecter</h1>

        <form method="POST" action="<?php echo e(route('investor.login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="inv-login-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="email" class="inv-login-label">Email *</label>
                <input type="email" name="email" id="email" class="inv-login-input" value="<?php echo e(old('email')); ?>" required autofocus>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inv-login-error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <div class="inv-login-group <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="password" class="inv-login-label">Mot de passe *</label>
                <input type="password" name="password" id="password" class="inv-login-input" required>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inv-login-error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <button type="submit" class="inv-login-btn">Se connecter</button>
        </form>

        <div class="inv-login-links">
            <div>Pas encore inscrit ? <a href="<?php echo e(route('investor.register')); ?>">S'inscrire</a></div>
            <div><a href="<?php echo e(route('investor.password.request')); ?>">Mot de passe oublié ?</a></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/investor/login.blade.php ENDPATH**/ ?>