

<?php $__env->startSection('title', 'Mot de passe oublié - Investisseur'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .inv-fp-container { width: min(100%, 500px); margin: 40px auto; }
    .inv-fp-box { background: #fff; border: 1px solid #dfe3ea; border-radius: 8px; padding: 24px; }
    .inv-fp-h1 { margin: 0 0 12px; font-size: 1.8rem; color: #333; }
    .inv-fp-subtitle { color: #6b7280; margin-bottom: 24px; font-size: 0.95rem; }
    .inv-fp-group { margin-bottom: 16px; }
    .inv-fp-label { display: block; margin-bottom: 6px; font-weight: 600; font-size: 0.9rem; color: #333; }
    .inv-fp-input { width: 100%; padding: 10px; border: 1px solid #dfe3ea; border-radius: 4px; font-size: 0.95rem; font-family: Arial, sans-serif; color: #333; }
    .inv-fp-input:focus { outline: none; border-color: #E8490F; box-shadow: 0 0 0 3px rgba(232, 73, 15, 0.1); }
    .inv-fp-error { color: #dc2626; font-size: 0.85rem; margin-top: 4px; }
    .inv-fp-success { background: #d1fae5; color: #065f46; padding: 12px; border-radius: 4px; margin-bottom: 16px; font-size: 0.9rem; }
    .inv-fp-group.error .inv-fp-input { border-color: #dc2626; }
    .inv-fp-btn { display: inline-flex; width: 100%; align-items: center; justify-content: center; min-height: 44px; background: #E8490F; color: #fff; border: none; border-radius: 6px; font-size: 0.95rem; font-weight: 700; cursor: pointer; margin-top: 12px; }
    .inv-fp-btn:hover { background: #C73D0A; }
    .inv-fp-link { text-align: center; margin-top: 16px; }
    .inv-fp-link a { color: #E8490F; text-decoration: none; font-weight: 600; }
    @media (max-width: 600px) { .inv-fp-container { margin: 20px auto; } .inv-fp-box { padding: 18px; } }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="inv-fp-container">
    <div class="inv-fp-box">
        <h1 class="inv-fp-h1">Mot de passe oublié</h1>
        <p class="inv-fp-subtitle">Entrez votre adresse email pour recevoir un lien de réinitialisation.</p>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
            <div class="inv-fp-error">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('status')): ?>
            <div class="inv-fp-success">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

        <form method="POST" action="<?php echo e(route('investor.password.email')); ?>">
            <?php echo csrf_field(); ?>

            <div class="inv-fp-group <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label for="email" class="inv-fp-label">Email *</label>
                <input type="email" name="email" id="email" class="inv-fp-input" value="<?php echo e(old('email')); ?>" required autofocus>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inv-fp-error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <button type="submit" class="inv-fp-btn">Envoyer le lien</button>
        </form>

        <div class="inv-fp-link">
            <a href="<?php echo e(route('investor.login')); ?>">Retour à la connexion</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Nathan\Desktop\appj2\resources\views/investor/forgot-password.blade.php ENDPATH**/ ?>